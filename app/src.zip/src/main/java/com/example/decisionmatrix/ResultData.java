package com.example.decisionmatrix;

public class ResultData {
}
